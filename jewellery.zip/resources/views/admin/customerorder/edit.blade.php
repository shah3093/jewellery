<section class="content">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <form id="frmAdd" role="form" action="{{route('admin.slider.add.data',['id'=>$result->id])}}" method="post"
                  enctype="multipart/form-data">
                <div class="box">
                    <div class="box-body">

                        <!-- general form elements -->
                        <div class="box box-primary">
                            <!-- /.box-header -->
                            <div id="errorDiv" style="display: none;">
                                <div class="callout callout-danger">
                                    <h4 id="errormsg"></h4>
                                </div>
                            </div>
                            <!-- form start -->
                            <input type="hidden" name="_token" value="{{csrf_token() }}"/>

                            <!-- /.box-body -->


                            <div class="box-body">
                                <div class="form-group" id="imgshwdiv">
                                    <img src="{{URL::asset('storage/'.$result->file_name)}}" class="img-thumbnail" style="height: 250px" />
                                    <span class="deletefiledb btn requiredStar" 
                                          data-url="{{route('admin.slider.deletefile',['id'=>$result->id])}}"
                                          ><i
                                            class="fa fa-trash"></i>
                                    </span>
                                </div>
                                <div class="form-group hidden" id="imginput">
                                    <label for="exampleInputFile">Image input <span
                                            class="requiredStar">*</span></label>
                                    <input id="exampleInputFile" name="img"  type="file">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Caption <span class="requiredStar">*</span></label>
                                    <input value="{{$result->caption}}" name="fData[caption]" class="form-control required" id="exampleInputEmail1" type="text">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Details</label>
                                    <textarea name="fData[details]" class="form-control" id="exampleInputPassword1"> {{$result->details}}</textarea>
                                </div>
                            </div>
                            <!-- /.box-body -->


                        </div>
                        <!-- /.box -->


                    </div>
                    <div class="box-footer">
                        <a id="cancel" class="btn btn-danger btnCancel refreshBook"><span class="fa fa-close"></span> CANCEL</a>
                        <a href="#" id="submitform" class="btn  btn-success pull-right"><span class="fa fa-save"></span>
                            SAVE</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<script>
    $(function () {
        $('.summernote').summernote({
            height: 500
        });
    });
</script>