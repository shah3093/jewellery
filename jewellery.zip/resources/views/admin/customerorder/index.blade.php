@extends('admin.layouts.master')

@section('title')
Dashboard
@endsection

@section('content')
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Orders
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row" style="">

    </div>

    <div class="row">
        <div class="col-md-12 common-content" id="contentform">

        </div>
    </div>

    <div class="row">

        <div class="col-md-12 common-content" id="listing">

            <h4>Loading ....</h4>

        </div>
    </div>
    <!-- /.row -->

</section>
<!-- /.content -->
@endsection

@push('scripts')
<script>
    var current_url = "{{route('admin.customerorder.listing')}}";
</script>

<script src="{{URL::to('admin/customs/js/customerorder.js')}}"></script>
@endpush