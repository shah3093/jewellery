<section class="content">
    <div class="row">

        <div class="col-md-12">
            <form id="frmAdd" role="form" action="{{route('admin.customerorder.add.data',['id'=>$result->id])}}" method="post"
                  enctype="multipart/form-data">
                <div class="box">
                    <div class="box-body">

                        <!-- Main content -->
                        <section class="invoice">
                            <!-- title row -->
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2 class="page-header">
                                        <i class="fa fa-globe"></i> Jewellery shop
                                    </h2>
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- info row -->
                            <div class="row invoice-info">
                                <div class="col-sm-4 invoice-col">

                                    <address>
                                        <strong>{{$result->customer->name}}</strong><br>
                                        {{$result->address}}
                                        <b>Phone:</b> {{$result->customer->phone}}<br>
                                        <b>Email:</b> {{$result->customer->email}}
                                    </address>
                                </div>
                                <!-- /.col -->
                                <div class="col-sm-4 invoice-col">

                                </div>
                                <!-- /.col -->
                                <div class="col-sm-4 invoice-col">
                                    <b>Order ID: {{$result->orderid}}</b><br>
                                    <br>
                                    <b>Payment type:</b> {{$result->paymentType}}<br>
                                    <b>Payment id:</b> {{$result->payment_id}}<br>
                                    <b>Status:</b> {{$result->status}}<br>
                                    <b>Order date:</b> {{date("d-m-Y",strtotime($result->created_at))}}
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->

                            <!-- Table row -->
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-xs-12 table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Image</th>
                                                <th>Product</th>
                                                <th>Qty</th>
                                                <th>Price #</th>
                                                <th>Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $subtotal = 0;
                                            ?>
                                            @foreach($carts as $cart)
                                            <tr>
                                                <td><img style="width: 60px;height: 50px" src="{{URL::asset('storage/'.$cart['productimg'])}}" alt=""></td>
                                                <td>{{$cart['productname']}}</td>
                                                <td>{{$cart['quantity']}}</td>
                                                <td>{{$cart['price']}} BDT</td>
                                                <td>{{$cart['price']*$cart['quantity']}} BDT</td>
                                                <?php $subtotal = $subtotal + ($cart['price'] * $cart['quantity']); ?>
                                            </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->

                            <div class="row">
                                <!-- accepted payments column -->
                                <div class="col-xs-6">
                                    <p class="lead">Payment type: <b>{{$result->paymentType}}</b></p>
                                    @if($result->payment_id != null)
                                    <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                                        <b>Payment ID: </b> {{$result->payment_id}}
                                    </p>
                                    @endif

                                    <p class="lead">Shipping address:</p>
                                    <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                                        {{$result->shippingaddress}}
                                    </p>

                                    <p class="lead">Comment: <span class="requiredStar">*</span></p>
                                    <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                                        <textarea class="form-control required" name="comment">{{$result->comment}}</textarea>
                                    </p>
                                </div>
                                <!-- /.col -->
                                <div class="col-xs-6">
                                    <p class="lead">Amount</p>

                                    <div class="table-responsive">
                                        <table class="table">
                                            <tr>
                                                <th style="width:50%">Subtotal:</th>
                                                <td>{{$subtotal }} BDT</td>
                                            </tr>

                                            <tr>
                                                <th>Shipping:</th>
                                                <td>Free</td>
                                            </tr>
                                            <tr>
                                                <th>Total:</th>
                                                <td>{{$subtotal }} BDT</td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="row">
                                        <h2 class="lead"><strong>Order confirmation</strong></h2>
                                        <div class="funkyradio">
                                            <div class="col-md-4">
                                                <div class="funkyradio-danger">
                                                    <input type="radio" name="status" value="CANCELED" id="radio2" />
                                                    <label for="radio2">Cancel</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="funkyradio-warning ">
                                                    <input type="radio" name="status" value="PENDING" id="radio3" checked/>
                                                    <label for="radio3">Pending</label>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="funkyradio-success ">
                                                    <input type="radio" name="status" value="CONFIRMED" id="radio4" />
                                                    <label for="radio4">Complete</label>
                                                    <input type="hidden" name="_token" value="{{csrf_token() }}"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->

                            <!-- this row will not appear when printing -->
                            <div class="row no-print">
                                <div class="col-xs-12">
<!--                                    <button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
                                        <i class="fa fa-download"></i> Generate PDF
                                    </button>-->



                                </div>
                            </div>
                        </section>
                        <!-- /.content -->
                        <div class="clearfix"></div>
                    </div>

                </div>
                <div class="box-footer">
                    <a id="cancel" class="btn btn-danger btnCancel refreshBook"><span class="fa fa-close"></span> CANCEL</a>
                    <a href="#" id="submitform" class="btn  btn-success pull-right"><span class="fa fa-save"></span>
                        SAVE</a>
                </div>
        </div>
        </form>
    </div>
</div>
</section>
