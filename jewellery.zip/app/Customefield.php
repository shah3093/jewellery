<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customefield extends Model {

    //
    protected $fillable = ['field_title', 'field_data', 'table_name', 'table_id'];

}
