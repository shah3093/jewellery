$(function () {
    load_data(current_url);

    $("body").on("click", "#addform", function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        $("#listing").html(" ");
        $.post(url, {_token: _token}, function (result) {
            $("#listing").html(" ");
            $("#addform").hide();
            $("#contentform").html(result);
        });
    });
    //
    $("body").on("click", "#cancel", function (e) {
        e.preventDefault();
        $("#addform").show();
        load_data(current_url);
    });
    //


    $("body").on("click", "#submitform", function (e) {
        e.preventDefault();
        var check = 0;
        $(".required").each(function () {
            if (!$(this).val()) {
                $(this).parent().addClass("has-error");
                check = 1;
            } else {
                $(this).parent().removeClass("has-error");
            }
        });
        if (check == 0) {
            var data = new FormData(document.getElementById("frmAdd"));
            var url = $("#frmAdd").attr('action');
            datainsertdb(data, url);
        }
    });

    $("body").on("click", ".edit", function (e) {
        e.preventDefault();
        var url = $(this).attr("data-url");
        $("#listing").html(" ");
        $.post(url, {_token: _token}, function (result) {
            $("#listing").html(" ");
            $("#addform").hide();
            $("#contentform").html(result);
        });
    });
    //
    $("body").on("click", ".delete", function (e) {
        e.preventDefault();
        var url = $(this).attr("data-url");
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: true
            },
            function () {
                $.post(url, {_token: _token}, function () {
                    load_data(current_url);
                });
            });
    });
    //
    //
    //


    $("body").on("click", ".deletefrm", function (e) {
        e.preventDefault();
        var id = $(this).attr("data-parentid");
        $("#" + id).remove();
    });
    //
    $("body").on("click", ".deletefiledb", function (e) {
        e.preventDefault();
        var url = $(this).attr("data-url");
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this file!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: true
            },
            function () {
                $.post(url, {_token: _token}, function () {
                    $("#imgshwdiv").remove();
                    $("#imginput").removeClass("hidden");
                });
            });

    });

    //
    //
    $("body").on("change", ".imgtypecheck", function (e) {
        e.preventDefault();
        var ext = $(this).val().split('.').pop().toLowerCase();
        if ($.inArray(ext, ['gif', 'jpg', 'png', 'jpeg']) == -1) {
            alert('invalid extension!');
            $(this).val("");
        }
    });
    //
    //

    //
    //


});