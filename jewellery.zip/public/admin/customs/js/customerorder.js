$(function () {
    load_data(current_url);

    $("body").on("click", "#addform", function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        $("#listing").html(" ");
        $.post(url, {_token: _token}, function (result) {
            $("#listing").html(" ");
            $("#addform").hide();
            $("#contentform").html(result);
        });
    });
    //
    $("body").on("click", "#cancel", function (e) {
        e.preventDefault();
        $("#addform").show();
        load_data(current_url);
    });
    //


    $("body").on("click", "#submitform", function (e) {
        e.preventDefault();
        var check = 0;
        $(".required").each(function () {
            if (!$(this).val()) {
                $(this).parent().addClass("has-error");
                check = 1;
            } else {
                $(this).parent().removeClass("has-error");
            }
        });
        if (check == 0) {
            var data = new FormData(document.getElementById("frmAdd"));
            var url = $("#frmAdd").attr('action');
            datainsertdb(data, url);
        }
    });

    $("body").on("click", ".edit", function (e) {
        e.preventDefault();
        var url = $(this).attr("data-url");
        $("#listing").html(" ");
        $.post(url, {_token: _token}, function (result) {
            $("#listing").html(" ");
            $("#addform").hide();
            $("#contentform").html(result);
        });
    });
    //
    $("body").on("click", ".delete", function (e) {
        e.preventDefault();
        var url = $(this).attr("data-url");
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this data!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: true
            },
            function () {
                $.post(url, {_token: _token}, function () {
                    load_data(current_url);
                });
            });
    });
    //
    //
    //
    $("body").on("click", ".addimage", function (e) {
        e.preventDefault();
        var url = $(this).attr('data-url');
        var cnt = $(this).attr("data-imagecnt");
        $(this).attr("data-imagecnt", ++cnt);
        $.post(url + "/img/" + cnt, {_token: _token}, function (result) {
            $("#moreimage").append(result);
        });
    });

    $("body").on("click", ".addfile", function (e) {
        e.preventDefault();
        var cnt = $(this).attr("data-filecnt");
        var url = $(this).attr('data-url');
        $(this).attr("data-filecnt", ++cnt);
        $.post(url + "/file/" + cnt, {_token: _token}, function (result) {
            $("#morefile").append(result);
        });
    });

    $("body").on("click", ".addfield", function (e) {
        e.preventDefault();
        var cnt = $(this).attr("data-filecnt");
        var url = $(this).attr('data-url');
        $(this).attr("data-filecnt", ++cnt);
        $.post(url + "/field/" + cnt, {_token: _token}, function (result) {
            $("#morefiled").append(result);
        });
    });

    $("body").on("click", ".deletefrm", function (e) {
        e.preventDefault();
        var id = $(this).attr("data-parentid");
        $("#" + id).remove();
    });
    //
    $("body").on("click", ".deletefiledb", function (e) {
        e.preventDefault();
        var parentid = $(this).attr("data-parentid");
        var id = $(this).attr("data-id");
        var url = $(this).attr("data-url");
        var type = $(this).attr("data-type");

        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this file!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: true
            },
            function () {
                $.post(url, {_token: _token}, function () {
                    $("#" + parentid).remove();
                });
            });

    });

    //
    //
    $("body").on("change", ".imgtypecheck", function (e) {
        e.preventDefault();
        var ext = $(this).val().split('.').pop().toLowerCase();
        if ($.inArray(ext, ['gif', 'jpg', 'png', 'jpeg']) == -1) {
            alert('invalid extension!');
            $(this).val("");
        }
    });
    //
    //
    $("body").on("change", "#pagetitle", function (e) {
        var title = $("#pagetitle").val();
        var url = $("#pagetitle").attr('data-url');
        $.post(url, {title: title,_token: _token}, function (result) {
            $("#slug").val(result);
            $("#slugvalue").val(result);
        });
    });

    $("body").on("change", "#slug", function (e) {
        var slug = $("#slug").val();
        var previousval = $("#slugvalue").val();
        var url = $("#slug").attr('data-url');
        $.post(url, {title: slug,_token: _token}, function (result) {
            if (result == 'WRONG') {
                $("#slug").val(previousval);
                alert("This slug is already using");
            } else {
                $("#slug").val(result);
                $("#slugvalue").val(result);
            }
        });
    });
    //
    //


});