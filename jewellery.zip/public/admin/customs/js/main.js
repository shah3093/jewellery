function load_data(url) {
    $.post(url, {_token:_token}, function (resp) {
        $("#listing").html(resp);
        $("#contentform").html(" ");
    });
}


function datainsertdb(data, url) {
    $.ajax({
        type: 'POST',
        url: url,
        data: data,
        async: false,
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        success: function (resp) {
            if (resp != 'DONE') {
                $("#errorDiv").show();

                var str = resp.toString();
                str = str.replace(".","<br/>");

                $("#errormsg").html(str)
                $("#contentform").show();
            } else {
                $("#addform").show();
                $("#contentform").show();
                load_data(current_url);
            }
        }
    });

}

