$('.add-to-cart').on('click', function (e) {
    e.preventDefault();
    var cart = $('#cartimg');
    var imgtodrag = $("#productfontimg");

    if (imgtodrag) {
        var imgclone = imgtodrag.clone()
                .offset({
                    top: imgtodrag.offset().top,
                    left: imgtodrag.offset().left
                })
                .css({
                    'opacity': '0.5',
                    'position': 'absolute',
                    'height': '150px',
                    'width': '150px',
                    'z-index': '100'
                })
                .appendTo($('body'))
                .animate({
                    'top': cart.offset().top + 10,
                    'left': cart.offset().left + 10,
                    'width': 75,
                    'height': 75
                }, 1000, 'easeInOutExpo');

        setTimeout(function () {
            cart.effect("shake", {
                times: 2
            }, 200);
        }, 1500);

        imgclone.animate({
            'width': 0,
            'height': 0
        }, function () {
            $(this).detach()
        });
    }

    var productid = $(this).attr('data-productid');
    var productqty = $("#productqty").val();
    var url = $(this).attr('data-url');

    $.post(url, {_token: _token, productid: productid, productqty: productqty}, function (result) {
        $('.miniCartScetion').html(result);
    });

});



$(".updateQuantity").on('click', function (e) {
    e.preventDefault();
    var rowid = $(this).attr('data-rowid');
    var url = $(this).attr('data-url');
    var qtyid = $(this).attr('data-quantity_id');
    var qty = $("#" + qtyid).val();
    $.post(url, {_token: _token, rowid: rowid, qty: qty}, function (result) {
        $('.miniCartScetion').html(result);
        location.reload(true);
    });
});


$("body").on("click", "#submitform", function (e) {
    e.preventDefault();
    var customerprofile = null;
    customerprofile = $(this).attr('data-userprofile');
    var check = 0;

    $(".required").each(function () {
        if (!$(this).val()) {
            $(this).addClass("has-error");
            check = 1;
        } else {
            $(this).removeClass("has-error");
        }
    });

    if (check == 0) {
        var data = new FormData(document.getElementById("frmAdd"));
        var url = $("#frmAdd").attr('action');
        datainsertdb(data, url, customerprofile);
    }
});

function datainsertdb(data, url, linktoload = null) {
    $.ajax({
        type: 'POST',
        url: url,
        data: data,
        async: false,
        enctype: 'multipart/form-data',
        processData: false,
        contentType: false,
        cache: false,
        success: function (resp) {
            if (resp != 'DONE') {
                $("#errorDiv").show();

                var str = resp.toString();
                str = str.replace(".", "<br/>");

                $("#errormsg").html(str);
                $("#contentform").show();
            } else {
                if (linktoload != null) {
                    location.href = linktoload;
                } else {
                    location.reload();
                }
            }
        }
    });

  

}